# SumOne-Challenge

Reposit�rio com minha solu��o para o challenge dado � mim pela SumOne como parte do processo seletivo para est�gio em web development.


Challenge: Servi�o de Ordena��o


Linguagem utilizada: Python 3.7 - 64 bits

  

O Servi�o de Ordena��o tem o objetivo de organizar os livros em uma biblioteca. Ele possui mais de 50 possibilidades de ordena��o, dando ao usu�rio a chance de escolher sua prefer�ncia. Existem duas maneiras de executar o programa: atrav�s de um arquivo .exe, este dispensa qualquer instala��o, e o programa em Python. Para executar este, siga as instru��es abaixo:             

-- INSTRU��ES PARA EXECU��O --
  
Voc� precisar� ter a vers�o mais atual de Python instalada em seu computador, caso deseje executar/alterar o c�digo fonte. Voc� pode encontrar Python em https://www.python.org/downloads/. No processo de instala��o, n�o esque�a de adicionar Python ao PATH, essa op��o est� dispon�vel no pr�prio instalador. Ou caso deseje, utilize a IDE de sua prefer�ncia.
  Voc� precisar� instalar as bibliotecas que foram utilizadas no programa, operator e tabulate. Para isso, instale o PIP. Ap�s instalar o Python e adicion�-lo ao PATH, abra o prompt de comando e digite 'python -m ensurepip' sem as aspas. Ap�s, digite 'python -m ensurepip --upgrade' tamb�m no console para garantir a �ltima vers�o do PIP.

-- BIBLIOTECAS --

Foram utilizadas duas bibliotecas do Python neste programa:

 
	
operator -> recurso "itemgetter". Busca um item do dicion�rio de acordo com sua "key".
	
tabulate -> cria o output no formato de tabela.



Para instalar ambas, abra o prompt de comando e digite 'pip install operator' e 'pip install tabulate'. Em caso de erro, voc� dever� instalar ambos manualmente. Busque o arquivo no formato 'wheel', de ambas as bibliotecas. Voc� pode encontrar um tutorial de como fazer esta instala��o manualmente com facilidade no Google.

                                                    
-- ARQUIVO .EXE --
 
Este programa tamb�m est� dispon�vel no formato .exe, como um aplicativo. Altera��es feitas no c�digo n�o ir�o afetar o aplicativo, por�m altera��es nos arquivos catalogo.txt e config.txt ir�o. 

                                               

-- ALTERANDO OS LIVROS --
 
Dentro da pasta com o execut�vel existe um arquivo chamado 'catalogo.txt'. Nele, est�o os livros a serem organizados. Esta lista pode ser alterada da forma que o usu�rio desejar, com adi��o ou remo��o de t�tulos, desde que o formato seja obedecido:
 
 
	
N�mero - T�tulo - Autor - Ano da Edi��o.
  
 

Para que o programa contabilize a altera��o, ela deve ser feita antes que o programa seja executado.

                                           

-- ALTERANDO AS CONFIGURA��ES --
  
O usu�rio possui a op��o de alterar as configura��es de ordena��o da forma como preferir. Dentro da pasta tamb�m existe um arquivo chamado 'config.txt'. Nele, est�o as configura��es que ser�o lidas pelo programa. Para fazer altera��es, basta o usu�rio escolher a prefer�ncia de ordena��o, esta configura��o ir� priorizar uma palavra chave dentre as outras, e a ordem de ordena��o do t�tulo, autor e ano. Para prefer�ncia de ordena��o, o usu�rio dever� escolher entre t�tulo, autor e ano. Para ordem de ordena��o, dever� escolher entre:

0 - indiferente, 1 - ascendente, 2 - descendente.
 
 
  
O arquivo .txt dever� ser organizado da seguinte forma:

  
    
Prefer�ncia de ordena��o; 
    
Ordem de ordena��o do t�tulo; 
    
Ordem de ordena��o do autor; 
    
Ordem de ordena��o do ano.
    
  

Caso o usu�rio n�o queira ordenar os livros, basta deixar o arquivo config.txt em branco.

                                                  

-- RESULTADOS --
  
O programa ordenar� os livros de acordo com a escolha do usu�rio. O resultado da ordena��o ser� exibido em forma de tabela.
  
	
EXEMPLO:

  
Para obter o resultado de ordena��o por ano e autor descendente e t�tulo ascendente, a configura��o do arquivo deve ser feita da seguinte forma:


		
Prefer�ncia de ordena��o: t�tulo
		
Ordem de ordena��o do t�tulo: 1
		
Ordem de ordena��o do autor: 2
		
Ordem de ordena��o do ano: 2

   

O resultado ser�:

-  -----------------------------------------------      ------------------  ----

4  Internet & World Wide Web: How to Program            Deitel&Deitel       2007


1  Java How to Program                                  Deitel&Deitel       2007


3  Head First Design Patterns                           Elisabeth Freeman   2004


2  Patterns of Enterprise Application Architecture      Martin Fowler       2002

-  -----------------------------------------------      ------------------  ---- 

  

T�tulo ser� a forma de diferencia��o entre livros com mesmo autor e ano, neste caso. 
